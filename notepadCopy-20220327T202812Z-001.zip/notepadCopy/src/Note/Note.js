import React, { Component } from "react";
// import PropTypes from "prop-types";

import "./Note.css";
class Note extends Component {
  constructor(props) {
    super(props);

    this.state = {};
    this.noteContent = props.noteContent;
    this.noteId = props.noteId;
    this.index=props.index

  }
  
  render() {
    return (
      <div className="note">
        <span className="noteIndex">{this.index}</span>
        <p className="noteContent">{this.noteContent}</p>
      </div>
    );
  }
}
// Note.propsType = { noteContent: PropTypes.string };

export default Note;
