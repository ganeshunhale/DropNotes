import "./App.css";
import Note from "./Note/Note";
// import { Component } from "react";
import NoteForm from "./NoteForm/NoteForm";
import { db } from "./config/config";
// import DB_CONFIG from "./config/config";
// import { initializeApp,database } from "firebase/app"
import {  collection, getDocs, addDoc } from "firebase/firestore";
import "firebase/database";
import { useEffect, useState } from "react";



// class App extends Component {
//   constructor(props) {
//     super(props);
//     this.addNotes = this.addNotes.bind(this);
// this.app = initializeApp(DB_CONFIG);
// this.db = this.app.database().ref().child("notes")

// this.state = {
//   notes: [
//     // { id: 1, noteContent: "note 1 here" },
//     // { id: 2, noteContent: "note 2 here" },
//   ],
// };

function App() {
  const [notes, setnotes] = useState(null);
  // const [inputeNoteState, setinputeNoteState] = useState([])
  const usersCollectionRef = collection(db, "Notes");

  useEffect(() => {
    getnotes();
  });
  const getnotes = async () => {
    // console.log("datattattataatat");
    if (!notes || notes?.length ===0){

      const data = await getDocs(usersCollectionRef);
      console.log("datattattataatat",data.docs);
  
      let mappedData=  data.docs.map((doc) => {
        console.log("doc.id++++++++++++",doc.id,indexedDB);
        
     return   {...doc.data(), id: doc.id ,}
      
      })
      setnotes(mappedData);
    }
  };
  //   const previouseNotes= this.state.notes;
  //   this.database.on("child_added",snap=>{
  //     previouseNotes.push({id:snap.key,
  //     noteContent:snap.val().noteContent})}}

  //     this.setState({notes:previouseNotes})
  //   })
  
  const addNotes = async(inputnote) => {
    // setinputeNoteState(inputnote)
    console.log("Inputnote",inputnote);
    // console.log("inputenotestate",inputeNoteState);

try {
  
  // await getnotes()
  // let added= await setDoc(doc(db,"Notes","33ALiWugodEcWvx2uDGg"),{name:inputnote,})
  let added= await addDoc(usersCollectionRef,{name:inputnote})
  
  console.log("added",added);
  
} catch (error) {
  console.log(error);
  
}
  


    // const previouseNotes = this.state.notes;
    // previouseNotes.push({id:previouseNotes.length+1,noteContent:note});
    // this.setState({ notes: previouseNotes });
    // this.database.push().set({noteContent:note})
  };

  return (
    <div className="notesWrapper">
      <div className="notesHeader">
        <div className="heading">Firebase Notes</div>
      </div>
      <div>
        <div className="notesFooter">
          <NoteForm addNotes={addNotes}></NoteForm>
        </div>
        <div className="notesBody">
          {/* {console.log(notes)} */}
          {notes?.map((note,index) => {
            console.log("note", note);
            return (
              <Note noteContent={note.name} index={index+1} noteId={note.id} key={note.id} />
            );
          })}
        </div>
      </div>
      {/* <div>
        {notes?.map((noteName) => {
          return (
            <div>
              <h1>Name: {noteName.name}</h1>
            </div>
          );
        })}
      </div> */}
    </div>
  );
}

export default App;
