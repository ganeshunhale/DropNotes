import React, { useState} from "react";
import "./NoteForm.css";
// class NoteForm extends Component {
//   constructor(props) {
//     super(props);

//     this.state = {
//         newNoteContent:'',
//     };
//   }
//   handleUserInput(e){
//       this.setState({
//           newNoteContent:e.target.value
//       })
//   }
//   render() {
//     return (
//       <div className="formWrapper">
//         {/* <input type={""} className="noteInput" placeholder="write a new note" /> */}

//         <textarea
//           id="note"
//           name="note"
//           className="noteInput"
//           placeholder="write a new note"
//           rows="4"
//           cols="100"
//           value={this.state.newNoteContent}
//           onChange={this.handleUserInput}
//         ></textarea>
//         <button className="noteButton">add note</button>
//         {/* <input type="submit" className="noteButton" value="Submit"></input> */}
//       </div>
//     );
//   }
// }

// export default NoteForm;

// import React from 'react'

function NoteForm({addNotes}) {
    const [newNoteContent, setNewNoteContent] = useState("")
    // console.log(props ,"proppsppppppppppppppp");
  return (
    <div className="formWrapper">
        {/* <input  id="note"
          name="note"
          className="noteInput"
          placeholder="write a new note"
          rows="4"
          cols="100"
          value={newNoteContent}
          onChange={e=> setNewNoteContent(e.target.value)}/> */}

        <textarea
          id="note"
          name="note"
          className="noteInput"
          placeholder="write a new note"
          rows="4"
          cols="100"
          value={newNoteContent}
          onChange={e=> setNewNoteContent(e.target.value)}
        ></textarea>
        <button className="noteButton" onClick={()=>{
            if(!newNoteContent){
                alert("add somthing in noteinput")
                return
            } 
            addNotes(newNoteContent)
            setNewNoteContent("")}}>add note</button>
        {/* <input type="submit" className="noteButton" value="Submit"></input> */}
      </div>
  )
}

export default NoteForm