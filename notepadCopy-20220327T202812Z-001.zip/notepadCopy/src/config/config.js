import { initializeApp } from "firebase/app"
import {getFirestore} from  '@firebase/firestore'
export const DB_CONFIG={

    apiKey: "AIzaSyBleteg70UvvXLRaWneecWgmqBSlZCY4gQ",
    authDomain: "notes-26902.firebaseapp.com",
    projectId: "notes-26902",
    storageBucket: "notes-26902.appspot.com",
    messagingSenderId: "242015768874",
    appId: "1:242015768874:web:469cc68ca55f24e18e0e53",
    measurementId: "G-0J1ZT58QWR"

}
const app = initializeApp(DB_CONFIG)
export const db =getFirestore(app)